# mii-param-biobank-manifest - MII IG Kerndatensatz-Modul Biobank v2027.0.0-ballot.rc2

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-param-biobank-manifest**

## Parameters: mii-param-biobank-manifest



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "mii-param-biobank-manifest",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-manifestparameters"]
  },
  "parameter" : [{
    "name" : "system-version",
    "valueCanonical" : "http://snomed.info/sct|http://snomed.info/sct/900000000000207008/version/20250701"
  },
  {
    "name" : "system-version",
    "valueCanonical" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes|3.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/shareablecodesystem|4.0.2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/shareablevalueset|4.0.2"
  },
  {
    "name" : "system-version",
    "valueCanonical" : "http://unitsofmeasure.org|3.0.1"
  },
  {
    "name" : "system-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Resource-id|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Resource-lastUpdated|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Resource-profile|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Resource-source|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-specimen-diagnose|2027.0.0-ballot.rc3"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Specimen-identifier|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Specimen-status|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Specimen-type|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Specimen-subject|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Specimen-patient|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Specimen-parent|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-specimen-request|2027.0.0-ballot.rc3"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Specimen-collected|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Specimen-bodysite|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-specimen-processing-procedure|2027.0.0-ballot.rc3"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-specimen-processing-additive|2027.0.0-ballot.rc3"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-specimen-processing-date|2027.0.0-ballot.rc3"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Specimen-container|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-specimen-container-additive|2027.0.0-ballot.rc3"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Substance-category|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Substance-code|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Organization-identifier|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Organization-name|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-status|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-category|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-code|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-date|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-focus|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-value-concept|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-value-quantity|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-code-value-concept|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-code-value-quantity|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-component-code|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-component-code-value-concept|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Observation-component-value-concept|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareableimplementationguide|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishableimplementationguide|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-implementationguide|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Organization|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-dna-konzentration|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-karyotyp|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-morphologie|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-zellinie-organoid|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-proliferation|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-qualitaetspruefung|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-wachstumstyp|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Element|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Condition|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-probenebene|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/ValueSet/body-site|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-biosafety-level|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/DocumentReference|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-cellline-modification-clo|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Observation|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/DomainResource|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/ValueSet/all-languages|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Specimen|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-dna-concentration-units-ucum|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-karyotyp-sct|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-cellline-morphology-sct|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-cellline-proliferation|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-wachstumstyp-clo|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Organization|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/KontaktRolle|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://fhir.de/StructureDefinition/address-de-basis|1.6.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Specimen.feature|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-ebene|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-infektiositaetsstatus|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.eu/fhir/laboratory/StructureDefinition/specimen-focus|2.0.0"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://terminology.hl7.org/ValueSet/v2-0487|3.0.0"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-probenart-sct|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Patient|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/EinstellungBlutversorgung|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/iso21090-PQ-translation|5.3.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/quantity-precision|5.3.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/SpecimenCore|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-body-structures-sct|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://terminology.hl7.org/ValueSet/v2-0916|3.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Temperaturbedingungen|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-laboratory-procedure-sct|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-containertyp-sct|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://terminology.hl7.org/ValueSet/v2-0371|3.0.0"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://terminology.hl7.org/ValueSet/v2-0493|3.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-anzahl-aliquots|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Substance|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ValueSet/mii-vs-biobank-substance-additive-sct|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-kulturprotokoll|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-modifikationen|2027.0.0-ballot.rc2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-anzahl-passagen|2027.0.0-ballot.rc2"
  }]
}

```
