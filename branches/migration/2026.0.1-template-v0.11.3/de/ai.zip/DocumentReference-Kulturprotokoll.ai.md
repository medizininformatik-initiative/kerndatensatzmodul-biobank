# Lungen-Organoid Kulturprotokoll - MII IG Kerndatensatz-Modul Biobank v2027.0.0-ballot.rc2

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Lungen-Organoid Kulturprotokoll**

## Beispiel DocumentReference: Lungen-Organoid Kulturprotokoll

-------

**German**

-------

**status**: Current

**date**: 2018-06-20 09:00:00+0100

**description**: Standardprotokoll zur Kultivierung von Lungentumor-Organoiden

> **content**

### Attachments

| | | | |
| :--- | :--- | :--- | :--- |
| - | **ContentType** | **Url** | **Title** |
| * | application/pdf | [https://biobank.uk-musterstadt.de/protocols/LungOrganoidCulture_v1.pdf](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.6.0&canonical=https://biobank.uk-musterstadt.de/protocols/LungOrganoidCulture_v1.pdf) | Lungen-Organoid Kulturprotokoll v1 |




## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "Kulturprotokoll",
  "status" : "current",
  "date" : "2018-06-20T09:00:00+01:00",
  "description" : "Standardprotokoll zur Kultivierung von Lungentumor-Organoiden",
  "content" : [{
    "attachment" : {
      "contentType" : "application/pdf",
      "url" : "https://biobank.uk-musterstadt.de/protocols/LungOrganoidCulture_v1.pdf",
      "title" : "Lungen-Organoid Kulturprotokoll v1"
    }
  }]
}

```
