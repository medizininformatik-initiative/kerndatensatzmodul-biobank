# MII CM Biobank Sample Type SPREC 4.0 SCT - MII IG Kerndatensatz-Modul Biobank v2027.0.0-ballot.rc2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII CM Biobank Sample Type SPREC 4.0 SCT**

## ConceptMap: MII CM Biobank Sample Type SPREC 4.0 SCT 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ConceptMap/mii-cm-biobank-sample-type-sprec-sct | *Version*:2027.0.0-ballot.rc2 |
| Active as of 2026-09-09 | *Computable Name*: |
| **Copyright/Legal**: This concept map includes content from SNOMED CT, which is copyright © 2002+ International Health Terminology Standards Development Organisation (IHTSDO), and distributed by agreement between IHTSDO and HL7. Implementer use of SNOMED CT is not covered by this agreement. It also includes content from SPREC 4.0, https://doi.org/10.1089/bio.2024.0010 | |

 
Mapping der SPREC 4.0 Sample Types auf die im Modul verwendeten SNOMED CT Codes. 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-biobank-sample-type-sprec-sct",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/StructureDefinition/mii-ex-meta-license-codeable",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://hl7.org/fhir/spdx-license",
        "code" : "CC-BY-4.0",
        "display" : "Creative Commons Attribution 4.0 International"
      }]
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/ConceptMap/mii-cm-biobank-sample-type-sprec-sct",
  "version" : "2027.0.0-ballot.rc2",
  "title" : "SPREC 4.0 Sample Type Mapping",
  "status" : "active",
  "date" : "2026-09-09T13:41:42+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Mapping der SPREC 4.0 Sample Types auf die im Modul verwendeten SNOMED CT Codes.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "This concept map includes content from SNOMED CT, which is copyright © 2002+ International Health Terminology Standards Development Organisation (IHTSDO), and distributed by agreement between IHTSDO and HL7. Implementer use of SNOMED CT is not covered by this agreement. It also includes content from SPREC 4.0, https://doi.org/10.1089/bio.2024.0010",
  "group" : [{
    "source" : "http://www.isber.org/sprec/type-of-sample",
    "target" : "http://snomed.info/sct",
    "element" : [{
      "code" : "ASC",
      "display" : "Ascites fluid",
      "target" : [{
        "code" : "309201001",
        "display" : "Ascitic fluid sample (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "AMN",
      "display" : "Amniotic fluid",
      "target" : [{
        "code" : "119373006",
        "display" : "Amniotic fluid specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "BAL",
      "display" : "Bronchoalveolar lavage",
      "target" : [{
        "code" : "258607008",
        "display" : "Bronchoalveolar lavage fluid sample (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "BLD",
      "display" : "Blood (whole)",
      "target" : [{
        "code" : "258580003",
        "display" : "Whole blood specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "BMA",
      "display" : "Bone marrow aspirate",
      "target" : [{
        "code" : "396997002",
        "display" : "Specimen from bone marrow obtained by aspiration (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "BMK",
      "display" : "Breast milk",
      "target" : [{
        "code" : "446676001",
        "display" : "Expressed breast milk specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "BUF",
      "display" : "Nondensity-gradient-centrifugation-separated buffy coat, viable",
      "target" : [{
        "code" : "258587000",
        "display" : "Buffy coat (specimen)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "BFF",
      "display" : "Nondensity-gradient-centrifugation-separated buffy coat, nonviable",
      "target" : [{
        "code" : "258587000",
        "display" : "Buffy coat (specimen)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "CEL",
      "display" : "Density-gradient-centrifugation-separated mononuclear cells, viable",
      "target" : [{
        "code" : "404798000",
        "display" : "Peripheral blood mononuclear cell (cell)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "BON",
      "display" : "Bone",
      "target" : [{
        "code" : "430268003",
        "display" : "Specimen from bone (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "CRD",
      "display" : "Cord blood",
      "target" : [{
        "code" : "122556008",
        "display" : "Cord blood specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "CSF",
      "display" : "Cerebrospinal fluid",
      "target" : [{
        "code" : "258450006",
        "display" : "Cerebrospinal fluid sample (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "EBC",
      "display" : "Exhaled breath condensate",
      "target" : [{
        "code" : "418468008",
        "display" : "Exhaled breath condensate (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FNA",
      "display" : "Cells from fine needle aspirate",
      "target" : [{
        "code" : "122550002",
        "display" : "Specimen obtained by fine needle aspiration procedure (specimen)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "HAR",
      "display" : "Hair",
      "target" : [{
        "code" : "119326000",
        "display" : "Hair specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "NAL",
      "display" : "Nails",
      "target" : [{
        "code" : "119327009",
        "display" : "Nail specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "NAS",
      "display" : "Nasal washing",
      "target" : [{
        "code" : "16224371000119105",
        "display" : "Nasal lavage fluid sample (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PLC",
      "display" : "Placenta",
      "target" : [{
        "code" : "119403008",
        "display" : "Specimen from placenta (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PFL",
      "display" : "Pleural fluid",
      "target" : [{
        "code" : "418564007",
        "display" : "Pleural fluid specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PTF",
      "display" : "Peritoneal fluid",
      "target" : [{
        "code" : "168139001",
        "display" : "Peritoneal fluid specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "RBC",
      "display" : "Red blood cells",
      "target" : [{
        "code" : "119351004",
        "display" : "Erythrocyte specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SEM",
      "display" : "Semen",
      "target" : [{
        "code" : "119347001",
        "display" : "Seminal fluid specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SPT",
      "display" : "Sputum",
      "target" : [{
        "code" : "119334006",
        "display" : "Sputum specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SYN",
      "display" : "Synovial fluid",
      "target" : [{
        "code" : "119332005",
        "display" : "Synovial fluid specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "TER",
      "display" : "Tears",
      "target" : [{
        "code" : "122594008",
        "display" : "Tears specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "TTH",
      "display" : "Teeth",
      "target" : [{
        "code" : "430319000",
        "display" : "Specimen from tooth (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SER",
      "display" : "Serum",
      "target" : [{
        "code" : "119364003",
        "display" : "Serum specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SAL",
      "display" : "Saliva",
      "target" : [{
        "code" : "119342007",
        "display" : "Saliva specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "STL",
      "display" : "Stool",
      "target" : [{
        "code" : "119339001",
        "display" : "Stool specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SWT",
      "display" : "Sweat",
      "target" : [{
        "code" : "122569007",
        "display" : "Sweat specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "U24",
      "display" : "24 h urine",
      "target" : [{
        "code" : "276833005",
        "display" : "24 hour urine sample (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "URN",
      "display" : "Urine, random (‘‘spot’’)",
      "target" : [{
        "code" : "278020009",
        "display" : "Spot urine sample (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "URM",
      "display" : "Urine, first morning",
      "target" : [{
        "code" : "258575007",
        "display" : "Early morning urine sample (specimen)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "URT",
      "display" : "Urine, timed",
      "target" : [{
        "code" : "409821005",
        "display" : " Timed urine specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "DWB",
      "display" : "Dried whole blood (e.g., Guthrie cards)",
      "target" : [{
        "code" : "119294007",
        "display" : "Dried blood specimen (specimen)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PL1",
      "display" : "Plasma, single spun",
      "target" : [{
        "code" : "119361006",
        "display" : "Plasma specimen (specimen)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "PL2",
      "display" : "Plasma, double spun",
      "target" : [{
        "code" : "119361006",
        "display" : "Plasma specimen (specimen)",
        "equivalence" : "wider"
      }]
    }]
  }]
}

```
