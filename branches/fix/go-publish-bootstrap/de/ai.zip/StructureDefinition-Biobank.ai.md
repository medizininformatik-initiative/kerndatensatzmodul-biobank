# MII_LM_Biobank - MII IG Kerndatensatz-Modul Biobank v2027.0.0-ballot.rc2

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII_LM_Biobank**

## Logisches Modell: MII_LM_Biobank 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/LogicalModel/Biobank | *Version*:2027.0.0-ballot.rc2 |
| Active Stand: 2026-09-09 | *Maschinenlesbarer Name*:MII_LM_Biobank |

 
Logische Repräsentation des Erweiterungsmoduls Biobank 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.biobank|current/StructureDefinition/StructureDefinition-Biobank.json)

### Formale Ansichten des Profilinhalts

 [Beschreibung von Profilen, Differentials, Snapshots und deren Repräsentationen](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Schlüsselelemente-Tabelle](#tabs-key) 
*  [Differential-Tabelle](#tabs-diff) 
*  [Snapshot-Tabelle](#tabs-snap) 
*  [Statistiken/Referenzen](#tabs-summ) 
*  [Alle](#tabs-all) 

#### Constraints

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

#### Constraints

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

** Summary **

 **Schlüsselelemente-Ansicht** 

#### Constraints

 **Differential-Ansicht** 

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

 **Snapshot-AnsichtView** 

#### Constraints

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

** Summary **

 

Weitere Repräsentationen des Profils: [CSV](../StructureDefinition-Biobank.csv), [Excel](../StructureDefinition-Biobank.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "Biobank",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/LogicalModel/Biobank",
  "version" : "2027.0.0-ballot.rc2",
  "name" : "MII_LM_Biobank",
  "status" : "active",
  "date" : "2026-09-09T12:40:12+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Logische Repräsentation des Erweiterungsmoduls Biobank",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "FHIR",
    "name" : "Biobank LogicalModel FHIR Mapping"
  }],
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/LogicalModel/Biobank",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Element",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "Biobank",
      "path" : "Biobank",
      "short" : "MII_LM_Biobank",
      "definition" : "Logische Repräsentation des Erweiterungsmoduls Biobank"
    },
    {
      "id" : "Biobank.Bioprobe",
      "path" : "Biobank.Bioprobe",
      "short" : "Details zu einer Bioprobe",
      "definition" : "Details zu einer Bioprobe",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Proben-ID",
      "path" : "Biobank.Bioprobe.Proben-ID",
      "short" : "Einrichtungsinterner Identifier der Probe",
      "definition" : "Einrichtungsinterner Identifier der Probe",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.identifier"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Probenart",
      "path" : "Biobank.Bioprobe.Probenart",
      "short" : "Art der Probe; SCT verpflichtend; Beschränkung auf Specimen ValueSet erwünscht.",
      "definition" : "Art der Probe; SCT verpflichtend; Beschränkung auf Specimen ValueSet erwünscht.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.type"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Probenmenge",
      "path" : "Biobank.Bioprobe.Probenmenge",
      "short" : "Probenmenge",
      "definition" : "Probenmenge",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.container.specimenQuantity"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Verfuegbarkeitsstatus",
      "path" : "Biobank.Bioprobe.Verfuegbarkeitsstatus",
      "short" : "Status der Probe / des Materials hinsichtlich der Verfügbarkeit",
      "definition" : "Status der Probe / des Materials hinsichtlich der Verfügbarkeit",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.status"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Projektverwendung",
      "path" : "Biobank.Bioprobe.Projektverwendung",
      "short" : "Freitextangabe zur Verwendung der Probe in Projekten",
      "definition" : "Freitextangabe zur Verwendung der Probe in Projekten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.note"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.SonstigeEigenschaften",
      "path" : "Biobank.Bioprobe.SonstigeEigenschaften",
      "short" : "Freitextangabe weiterer Probeneigenschaften",
      "definition" : "Freitextangabe weiterer Probeneigenschaften",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.note"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Entstanden-aus",
      "path" : "Biobank.Bioprobe.Entstanden-aus",
      "short" : "Referenz auf Bioprobe",
      "definition" : "Referenz auf Bioprobe",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.parent"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.FestgestellteDiagnose",
      "path" : "Biobank.Bioprobe.FestgestellteDiagnose",
      "short" : "Verweis auf eine Diagnose für die Material in der Probe enthalten ist",
      "definition" : "Verweis auf eine Diagnose für die Material in der Probe enthalten ist",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.extension[diagnose]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.gehoert-zu",
      "path" : "Biobank.Bioprobe.gehoert-zu",
      "short" : "Zuordnung der Probe zu einer Sammlung/Biobank",
      "definition" : "Zuordnung der Probe zu einer Sammlung/Biobank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.extension[gehoertZu]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Anzahl-Aliqouts",
      "path" : "Biobank.Bioprobe.Anzahl-Aliqouts",
      "short" : "Anzahl der Aliqouts.",
      "definition" : "Anzahl der Aliqouts.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.extension[anzahlAliquots]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Container",
      "path" : "Biobank.Bioprobe.Container",
      "short" : "Probenbehältnis",
      "definition" : "Probenbehältnis",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.container"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Container.Containertyp",
      "path" : "Biobank.Bioprobe.Container.Containertyp",
      "short" : "Typ des Containers",
      "definition" : "Typ des Containers",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.container.type"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Container.Kapazitaet",
      "path" : "Biobank.Bioprobe.Container.Kapazitaet",
      "short" : "Kapazität des Probencontainers",
      "definition" : "Kapazität des Probencontainers",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.container.capacity"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Container.VerwendungAdditiv",
      "path" : "Biobank.Bioprobe.Container.VerwendungAdditiv",
      "short" : "Ja/Nein Angabe, ob ein Zusatzstoff verwendet wurde",
      "definition" : "Ja/Nein Angabe, ob ein Zusatzstoff verwendet wurde",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.container.additive"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Container.Additiv",
      "path" : "Biobank.Bioprobe.Container.Additiv",
      "short" : "Zusatzstoffe im Container",
      "definition" : "Zusatzstoffe im Container",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.container.additive"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Probenentnahme",
      "path" : "Biobank.Bioprobe.Probenentnahme",
      "short" : "Informationen zur Entnahme der Probe",
      "definition" : "Informationen zur Entnahme der Probe",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.collection"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Probenentnahme.Entnahme-ID",
      "path" : "Biobank.Bioprobe.Probenentnahme.Entnahme-ID",
      "short" : "Entnahme-ID",
      "definition" : "Entnahme-ID",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.collection.request"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Probenentnahme.EinstellungBlutversorgung",
      "path" : "Biobank.Bioprobe.Probenentnahme.EinstellungBlutversorgung",
      "short" : "Zeitpunkt der Einstellung der Blutversorgung zur Probe. Kann zur Berechnung der warmen Ischaemiezeit verwendet werden.",
      "definition" : "Zeitpunkt der Einstellung der Blutversorgung zur Probe. Kann zur Berechnung der warmen Ischaemiezeit verwendet werden.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.collection.extension[einstellungBlutversorgung]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Probenentnahme.Entnahmezeitpunkt",
      "path" : "Biobank.Bioprobe.Probenentnahme.Entnahmezeitpunkt",
      "short" : "Zeitpunkt der Ent- / Abnahme der Probe. Kann zur Berechnung der kalten Ischaemiezeit verwendet werden.",
      "definition" : "Zeitpunkt der Ent- / Abnahme der Probe. Kann zur Berechnung der kalten Ischaemiezeit verwendet werden.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.collection.collected[x]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Probenentnahme.Entnahmestelle",
      "path" : "Biobank.Bioprobe.Probenentnahme.Entnahmestelle",
      "short" : "Lokalisation der Körperstelle, von der die Probe stammt",
      "definition" : "Lokalisation der Körperstelle, von der die Probe stammt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.collection.bodySite"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Probenentnahme.Nuechternstatus",
      "path" : "Biobank.Bioprobe.Probenentnahme.Nuechternstatus",
      "short" : "Nüchterstatus des:der Patent:in zum Zeitpunkt der Entnahme der Probe. Muss aus dem http://terminology.hl7.org/ValueSet/v2-0916 stammen.",
      "definition" : "Nüchterstatus des:der Patent:in zum Zeitpunkt der Entnahme der Probe. Muss aus dem http://terminology.hl7.org/ValueSet/v2-0916 stammen.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.collection.fastingStatusCodeableConcept"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Probenentnahme.NuechternstatusDauer",
      "path" : "Biobank.Bioprobe.Probenentnahme.NuechternstatusDauer",
      "short" : "Zeitliche Dauer der Nüchternheit vor der Probenentnahme",
      "definition" : "Zeitliche Dauer der Nüchternheit vor der Probenentnahme",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.collection.fastingStatusDuration"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Verarbeitungsprozess",
      "path" : "Biobank.Bioprobe.Verarbeitungsprozess",
      "short" : "Prozedur der Probenbearbeitung",
      "definition" : "Prozedur der Probenbearbeitung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Verarbeitungsprozess.Startzeitpunkt",
      "path" : "Biobank.Bioprobe.Verarbeitungsprozess.Startzeitpunkt",
      "short" : "Zeitpunkt des Beginns der Probenbearbeitung",
      "definition" : "Zeitpunkt des Beginns der Probenbearbeitung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing.timePeriod.start"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Verarbeitungsprozess.Endzeitpunkt",
      "path" : "Biobank.Bioprobe.Verarbeitungsprozess.Endzeitpunkt",
      "short" : "Zeitpunkt des Abschlusses der Probenbearbeitung",
      "definition" : "Zeitpunkt des Abschlusses der Probenbearbeitung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing.timePeriod.end"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Verarbeitungsprozess.Verarbeitungstyp",
      "path" : "Biobank.Bioprobe.Verarbeitungsprozess.Verarbeitungstyp",
      "short" : "Prozedur der Probenbearbeitung",
      "definition" : "Prozedur der Probenbearbeitung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing.procedure"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Verarbeitungsprozess.Temperatur",
      "path" : "Biobank.Bioprobe.Verarbeitungsprozess.Temperatur",
      "short" : "Temperatur bei der die Probenverarbeitung stattfand. Angabe exakt oder in Wertebereichen (siehe SPREC)",
      "definition" : "Temperatur bei der die Probenverarbeitung stattfand. Angabe exakt oder in Wertebereichen (siehe SPREC)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Range"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing.extension[temperaturbedingungen]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Verarbeitungsprozess.Modus",
      "path" : "Biobank.Bioprobe.Verarbeitungsprozess.Modus",
      "short" : "Abhängig vom Verarbeitungstyp - bei Zentrifugation SPREC",
      "definition" : "Abhängig vom Verarbeitungstyp - bei Zentrifugation SPREC",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing.procedure"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Verarbeitungsprozess.VerwendungAdditive",
      "path" : "Biobank.Bioprobe.Verarbeitungsprozess.VerwendungAdditive",
      "short" : "Ja/Nein Angabe, ob ein Zusatzstoff verwendet wurde",
      "definition" : "Ja/Nein Angabe, ob ein Zusatzstoff verwendet wurde",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing.additive"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Verarbeitungsprozess.Additiv",
      "path" : "Biobank.Bioprobe.Verarbeitungsprozess.Additiv",
      "short" : "Additive bei der Probenbearbeitung wie Fixationsmittel; Einbettungs- und Eindeckungsmedien",
      "definition" : "Additive bei der Probenbearbeitung wie Fixationsmittel; Einbettungs- und Eindeckungsmedien",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing.additive"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Lagerprozess",
      "path" : "Biobank.Bioprobe.Lagerprozess",
      "short" : "Lagerung einer Probe",
      "definition" : "Lagerung einer Probe",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing[lagerprozess]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Lagerprozess.Einlagerungszeitpunkt",
      "path" : "Biobank.Bioprobe.Lagerprozess.Einlagerungszeitpunkt",
      "short" : "Zeitpunkt des Beginns der Einlagerung der Probe",
      "definition" : "Zeitpunkt des Beginns der Einlagerung der Probe",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing[lagerprozess].timePeriod.start"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Lagerprozess.Auslagerungspunkt",
      "path" : "Biobank.Bioprobe.Lagerprozess.Auslagerungspunkt",
      "short" : "Zeitpunkt des Endes der Einlagerung der Probe",
      "definition" : "Zeitpunkt des Endes der Einlagerung der Probe",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing[lagerprozess].timePeriod.end"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Lagerprozess.Lagerungsbedingungen",
      "path" : "Biobank.Bioprobe.Lagerprozess.Lagerungsbedingungen",
      "short" : "Temperaturbereich in dem die Probe gelagert wurde bzw. wird. Angabe in Wertebereichen wie in SPREC",
      "definition" : "Temperaturbereich in dem die Probe gelagert wurde bzw. wird. Angabe in Wertebereichen wie in SPREC",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Range"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.processing[lagerprozess].extension[temperaturbedingungen]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Laborbefund",
      "path" : "Biobank.Bioprobe.Laborbefund",
      "short" : "Referenz auf den zu einer Probe gehörenden Laborbefund",
      "definition" : "Referenz auf den zu einer Probe gehörenden Laborbefund",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Pathologiebefund",
      "path" : "Biobank.Bioprobe.Pathologiebefund",
      "short" : "Referenz auf den zu einer Probe gehörenden Pathologiebefund",
      "definition" : "Referenz auf den zu einer Probe gehörenden Pathologiebefund",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid",
      "short" : "Beschreibung einer Zelllinie/eines Organoides. Alle Attribute der Bioprobe sind hier ebenfalls anwendbar.",
      "definition" : "Beschreibung einer Zelllinie/eines Organoides. Alle Attribute der Bioprobe sind hier ebenfalls anwendbar.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Phaenotyp-Diagnose",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Phaenotyp-Diagnose",
      "short" : "Phänotyp oder Diagnose der Zelllinie / des Organoids, wenn nicht patientenbezogen angebbar.",
      "definition" : "Phänotyp oder Diagnose der Zelllinie / des Organoids, wenn nicht patientenbezogen angebbar.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.extension[diagnose] / https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Karyotyp",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Karyotyp",
      "short" : "Karyotyp der Zelllinie/Organoids.",
      "definition" : "Karyotyp der Zelllinie/Organoids.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation(https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-karyotyp)"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Morphologie",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Morphologie",
      "short" : "Morphologie der Zelllinie/Organoids.",
      "definition" : "Morphologie der Zelllinie/Organoids.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation(https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-morphologie)"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Mutationen",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Mutationen",
      "short" : "Mögliche Mutationen der Zelllinie/Organoids.",
      "definition" : "Mögliche Mutationen der Zelllinie/Organoids.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation(Modul MolGen)"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Wachstumstyp",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Wachstumstyp",
      "short" : "Wachstumstyp der Zelllinie/Organoids.",
      "definition" : "Wachstumstyp der Zelllinie/Organoids.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation(https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-wachstumstyp)"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Zellproliferation",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Zellproliferation",
      "short" : "Art der Zellproliferation der Zelllinie/Organoids.",
      "definition" : "Art der Zellproliferation der Zelllinie/Organoids.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation(https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-proliferation)"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Passage",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Passage",
      "short" : "Anzahl der Passagen.",
      "definition" : "Anzahl der Passagen.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.extension[anzahlPassagen]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Modifikationen",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Modifikationen",
      "short" : "Optional: Vorgenommene Modifikationen.",
      "definition" : "Optional: Vorgenommene Modifikationen.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.extension[modifikationen]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Qualitaetspruefung",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Qualitaetspruefung",
      "short" : "Z.B. Viabilität, Test auf Mykoplasmen, Wiederauftaubarkeit / Wiederinkulturnahme.",
      "definition" : "Z.B. Viabilität, Test auf Mykoplasmen, Wiederauftaubarkeit / Wiederinkulturnahme.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation(https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-qualitaetspruefung)"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Protokoll-Kultur",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Protokoll-Kultur",
      "short" : "Kulturprotokoll der Zelllinie/Organoids.",
      "definition" : "Kulturprotokoll der Zelllinie/Organoids.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.extension[kulturprotokoll]"
      }]
    },
    {
      "id" : "Biobank.Bioprobe.Zelllinie-Organoid.Kulturbedigungen",
      "path" : "Biobank.Bioprobe.Zelllinie_Organoid.Kulturbedigungen",
      "short" : "Kulturbedingungen der Zelllinie/Organoids.",
      "definition" : "Kulturbedingungen der Zelllinie/Organoids.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank",
      "path" : "Biobank.Probensammlung-Biobank",
      "short" : "Organisation, die Proben verwaltet",
      "definition" : "Organisation, die Proben verwaltet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Kontakt",
      "path" : "Biobank.Probensammlung-Biobank.Kontakt",
      "short" : "Kontaktinformationen einer Sammlung/Biobank für Anfragen zu Bioproben",
      "definition" : "Kontaktinformationen einer Sammlung/Biobank für Anfragen zu Bioproben",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.contact"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Kontakt.Vorname",
      "path" : "Biobank.Probensammlung-Biobank.Kontakt.Vorname",
      "short" : "Vorname der Ansprechperson",
      "definition" : "Vorname der Ansprechperson",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.contact.given"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Kontakt.Nachname",
      "path" : "Biobank.Probensammlung-Biobank.Kontakt.Nachname",
      "short" : "Nachname der Ansprechperson",
      "definition" : "Nachname der Ansprechperson",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.contact.family"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Kontakt.E-Mail",
      "path" : "Biobank.Probensammlung-Biobank.Kontakt.E-Mail",
      "short" : "E-Mailadresse für Anfragen",
      "definition" : "E-Mailadresse für Anfragen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.contact.telecom[email]"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Kontakt.Rolle",
      "path" : "Biobank.Probensammlung-Biobank.Kontakt.Rolle",
      "short" : "Rolle der Ansprechperson in der Sammlung/Biobank",
      "definition" : "Rolle der Ansprechperson in der Sammlung/Biobank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.contact.extension[rolle]"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Kontakt.Adresse",
      "path" : "Biobank.Probensammlung-Biobank.Kontakt.Adresse",
      "short" : "Kontaktadresse für Forschungsvorhaben",
      "definition" : "Kontaktadresse für Forschungsvorhaben",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Address"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.contact.address"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Sammlungs-ID",
      "path" : "Biobank.Probensammlung-Biobank.Sammlungs-ID",
      "short" : "Interner Identifer der Sammlung/Biobank",
      "definition" : "Interner Identifer der Sammlung/Biobank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.identifier"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.BBMRI-ERIC-ID",
      "path" : "Biobank.Probensammlung-Biobank.BBMRI-ERIC-ID",
      "short" : "Identifier der Sammlung/Biobank im BBMRI ERIC Netzwerk",
      "definition" : "Identifier der Sammlung/Biobank im BBMRI ERIC Netzwerk",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.identifier[bbmri-eric-id]"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Akronym",
      "path" : "Biobank.Probensammlung-Biobank.Akronym",
      "short" : "Akronym der Sammlung/Biobank",
      "definition" : "Akronym der Sammlung/Biobank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.alias"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Name",
      "path" : "Biobank.Probensammlung-Biobank.Name",
      "short" : "Name der Sammlung/Biobank",
      "definition" : "Name der Sammlung/Biobank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.name"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Beschreibung",
      "path" : "Biobank.Probensammlung-Biobank.Beschreibung",
      "short" : "Beschreibung der Sammlung/Biobank",
      "definition" : "Beschreibung der Sammlung/Biobank",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.extension[beschreibung]"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.Sammlungstyp",
      "path" : "Biobank.Probensammlung-Biobank.Sammlungstyp",
      "short" : "Typ der Sammlung/Biobank gemäß BBMRI ERIC Directory Werteliste",
      "definition" : "Typ der Sammlung/Biobank gemäß BBMRI ERIC Directory Werteliste",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.extension[collectionSetting] / Biobank.extension[collectionDesign]"
      }]
    },
    {
      "id" : "Biobank.Probensammlung-Biobank.besteht-aus",
      "path" : "Biobank.Probensammlung-Biobank.besteht-aus",
      "short" : "Verknüpfung der Teilsammlungen",
      "definition" : "Verknüpfung der Teilsammlungen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Biobank.partOf"
      }]
    }]
  }
}

```
